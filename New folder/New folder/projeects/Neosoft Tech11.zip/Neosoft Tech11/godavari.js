function myFunction() {
    var dots = document.getElementById("dots");
    var moreText = document.getElementById("more");
    var btnText = document.getElementById("myBtn");
  
    if (dots.style.display === "none") {
      dots.style.display = "inline";
      btnText.innerHTML = "Know more";
      moreText.style.display = "none";
    } else {
      dots.style.display = "none";
      btnText.innerHTML = "Know less";
      moreText.style.display = "inline";
    }
  }
  function myFunctio() {
    var dots = document.getElementById("dot");
    var moreText = document.getElementById("mor");
    var btnText = document.getElementById("myBt");
  
    if (dots.style.display === "none") {
      dots.style.display = "inline";
      btnText.innerHTML = "Know more";
      moreText.style.display = "none";
    } else {
      dots.style.display = "none";
      btnText.innerHTML = "Know less";
      moreText.style.display = "inline";
    }
  }
  function myFuncti() {
    var dots = document.getElementById("do");
    var moreText = document.getElementById("mo");
    var btnText = document.getElementById("myB");
  
    if (dots.style.display === "none") {
      dots.style.display = "inline";
      btnText.innerHTML = "view more";
      moreText.style.display = "none";
    } else {
      dots.style.display = "none";
      btnText.innerHTML = "view less";
      moreText.style.display = "inline";
    }
  }